package main

import _ "run/subdir/internal/private"

func main() {}
