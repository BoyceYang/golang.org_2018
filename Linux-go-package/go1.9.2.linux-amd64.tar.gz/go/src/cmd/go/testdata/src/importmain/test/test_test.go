package test_test

import "testing"
import _ "importmain/ismain"

func TestCase(t *testing.T) {}
