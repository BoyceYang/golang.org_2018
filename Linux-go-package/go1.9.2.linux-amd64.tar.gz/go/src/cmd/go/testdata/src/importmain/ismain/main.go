package main

import _ "importmain/test"

func main() {}
