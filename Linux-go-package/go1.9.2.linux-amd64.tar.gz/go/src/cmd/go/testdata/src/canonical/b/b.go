package b

import _ "canonical/a/"
