package p2
import _ "dupload/vendor/p"
