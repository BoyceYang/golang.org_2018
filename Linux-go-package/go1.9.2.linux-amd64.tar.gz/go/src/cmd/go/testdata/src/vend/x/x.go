package x

import _ "p"
import _ "q"
import _ "r"
import _ "vend/dir1"      // not vendored
import _ "vend/dir1/dir2" // vendored
