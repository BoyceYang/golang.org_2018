package pkg

var Text = "unset"
