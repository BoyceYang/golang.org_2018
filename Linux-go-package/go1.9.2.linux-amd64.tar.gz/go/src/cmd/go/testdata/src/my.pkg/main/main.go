package main
import "my.pkg"
func main() {
	println(pkg.Text)
}
