package main

import _ "run/internal"

func main() {}
