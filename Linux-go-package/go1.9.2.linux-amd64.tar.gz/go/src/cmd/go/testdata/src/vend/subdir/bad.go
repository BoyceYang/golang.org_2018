package subdir

import _ "r"
