package cgotest

import "C"

var _ C.int
