package invalid

import "vend/x/invalid/vendor/foo"
