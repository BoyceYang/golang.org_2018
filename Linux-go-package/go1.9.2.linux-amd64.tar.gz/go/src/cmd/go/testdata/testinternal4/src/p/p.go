package p

import (
	_ "q/internal/x"
	_ "q/j"
)
